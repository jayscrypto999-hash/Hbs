# HBS-Core

Human ByLigo System (HBS)

- Self-improving AI
- Runs perpetual loops
- Stores results in SQLite
- FastAPI web dashboard
- Ready to deploy on Render, Railway, or Fly.io

## How to deploy

1. Ensure Python 3.10+ is installed
2. Install dependencies:
```
pip install -r requirements.txt
```
3. Run:
```
uvicorn app:app --host 0.0.0.0 --port 8000
```
4. Open in browser:
```
http://localhost:8000
```
