import sqlite3, torch, torch.nn as nn, torch.optim as optim
import random, pickle, time
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
import threading

DB="hbs.db"
app = FastAPI()

def db():
    c=sqlite3.connect(DB)
    cur=c.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS commits(id INTEGER PRIMARY KEY,v INT,loss REAL,desc TEXT)")
    c.commit()
    return c,cur

class AI(nn.Module):
    def __init__(s,h): super().__init__(); s.l1=nn.Linear(1,h); s.l2=nn.Linear(h,1)
    def forward(s,x): return s.l2(torch.relu(s.l1(x)))

def train_ai():
    h=random.choice([16,32,64])
    m=AI(h)
    x=torch.arange(0,10).float().view(-1,1)
    y=2*x
    opt=optim.Adam(m.parameters(),0.01)
    lossf=nn.MSELoss()
    for _ in range(100):
        opt.zero_grad()
        loss=lossf(m(x),y)
        loss.backward()
        opt.step()
    return float(loss.item()),h

def loop():
    v=1
    while True:
        c,cur=db()
        best=(1e9,None)
        for _ in range(3):
            loss,h=train_ai()
            if loss<best[0]: best=(loss,h)
        cur.execute("INSERT INTO commits(v,loss,desc) VALUES(?,?,?)",(v,best[0],f'{best[1]} neurons'))
        c.commit()
        c.close()
        v+=1
        time.sleep(2)

threading.Thread(target=loop,daemon=True).start()

@app.get("/", response_class=HTMLResponse)
def ui():
    c,cur=db()
    cur.execute("SELECT * FROM commits ORDER BY id DESC LIMIT 10")
    rows=cur.fetchall()
    html="<h1>HBS LIVE</h1><table border=1><tr><th>Version</th><th>Loss</th><th>Desc</th></tr>"
    for r in rows:
        html+=f"<tr><td>{r[1]}</td><td>{r[2]:.6f}</td><td>{r[3]}</td></tr>"
    return html+"</table>"
